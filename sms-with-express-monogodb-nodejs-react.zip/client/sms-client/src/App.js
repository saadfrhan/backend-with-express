import Students from "./pages/Students/Students"
import ListOfStudents from "./pages/Students/ListOfStudents"
import Subjects from "./pages/Subjects/Subjects"

import {
  BrowserRouter,
  Switch,
  Route,
  Link
} from "react-router-dom";

function App() {
  return <>
    <BrowserRouter>

      <ul>
        <li> <Link to="/students">Create New Student</Link></li>
        <li> <Link to="/students-list">See All Students</Link></li>
        <li> <Link to="/subjects">Create New Subject</Link></li>
      </ul>

      <Switch>
        <Route path="/students">
          <Students />
        </Route>

        <Route path="/students-list">
          <ListOfStudents />
        </Route>

        <Route path="/subjects">
          <Subjects />
        </Route>

      </Switch>
    </BrowserRouter>
  </>
}

export default App;
