export default {
    server_base_url : 'http://localhost:9000'
}