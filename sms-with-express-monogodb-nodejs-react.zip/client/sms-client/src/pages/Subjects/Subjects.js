import Card from '@material-ui/core/Card';
import CardActions from '@material-ui/core/CardActions';
import CardContent from '@material-ui/core/CardContent';
import Button from '@material-ui/core/Button';
import TextField from '@material-ui/core/TextField';
import Select from '@material-ui/core/Select';
import MenuItem from '@material-ui/core/MenuItem';
import InputLabel from '@material-ui/core/InputLabel';
import FormHelperText from '@material-ui/core/FormHelperText';
import FormControl from '@material-ui/core/FormControl';
import { useState } from "react"
import SETTINGS from "../../settings"
import "./Subjects.css"



export default function Students() {

    let [subjectName, setSubjectName] = useState('')
    let [subjectClass, setSubjectClass] = useState('')


    function saveSubject(name, sClass){
        fetch(`${SETTINGS.server_base_url}/subjects/add-new`, {
            method : 'post',
            headers: {
                'Content-type': "application/json"
            },
            body: JSON.stringify({name, sClass})
        })
            .then(res => res.json())
            .then(data => {
                console.log("Response from Server ", data)

            })
    }


    return <>
        <Card className="create-subject-card">
            <CardContent>
                <form noValidate autoComplete="off">
                    <div>
                        <TextField required id="standard-required" label="Subject Name" onChange={(event) => { setSubjectName(event.target.value) }} />
                    </div>
                    <br />
                    <div>
                        <FormControl>
                            <InputLabel id="demo-simple-select-helper-label">Select Class</InputLabel>
                            <Select
                                onChange={(event) => { setSubjectClass(event.target.value) }}
                                id="demo-simple-select-helper"
                                labelId="demo-simple-select-helper-label"
                            >
                                <MenuItem value="">
                                    <em>None</em>
                                </MenuItem>
                                <MenuItem value={6}>VI</MenuItem>
                                <MenuItem value={7}>VII</MenuItem>
                                <MenuItem value={8}>VIII</MenuItem>
                                <MenuItem value={9}>IX</MenuItem>
                                <MenuItem value={10}>X</MenuItem>
                            </Select>
                            <FormHelperText>Some important helper text</FormHelperText>
                        </FormControl>

                    </div>
                </form>
                <br />
                <br />
                <br />
            </CardContent>
            <CardActions>
                <Button variant="contained" color="primary" onClick={() => { saveSubject(subjectName, subjectClass) }}>Save Subject</Button>
            </CardActions>
        </Card>
    </>
}