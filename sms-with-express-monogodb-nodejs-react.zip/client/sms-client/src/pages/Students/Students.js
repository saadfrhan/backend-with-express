
import Card from '@material-ui/core/Card';
import CardActions from '@material-ui/core/CardActions';
import CardContent from '@material-ui/core/CardContent';
import Button from '@material-ui/core/Button';
import TextField from '@material-ui/core/TextField';
import Select from '@material-ui/core/Select';
import MenuItem from '@material-ui/core/MenuItem';
import InputLabel from '@material-ui/core/InputLabel';
import FormHelperText from '@material-ui/core/FormHelperText';
import FormControl from '@material-ui/core/FormControl';
import { useState, useEffect } from "react"
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Checkbox from '@material-ui/core/Checkbox';
import SETTINGS from "../../settings"

export default function Students() {


    let [name, setName] = useState('')
    let [age, setAge] = useState('')
    let [gender, setGender] = useState('')
    let [studentClass, setStudentClass] = useState('')
    let [subjects, setSubjects] = useState('')
    let [allSubjects, setAllSubjects] = useState([])

    useEffect(() => {
        fetch(`${SETTINGS.server_base_url}/subjects/list-all`)
            .then(res => res.json())
            .then(subjectsList => {
                setAllSubjects(subjectsList.data)
            })
    }, [])


    function sendRequestToSaveStudent() {
        fetch(`${SETTINGS.server_base_url}/students/add-new`, {
            method: 'post',
            headers: {
                'Content-type': "application/json"
            },
            body: JSON.stringify({ name, age, gender, studentClass, subjects })
        })
            .then(res => res.json())
            .then(data => {
                console.log("Response from Server ", data)
                if(data.status){
                    alert("Student saved succesfully..!")
                    setName('')
                }
            })
    }

    return <>
        <Card className="create-subject-card">
            <CardContent>
                <form noValidate autoComplete="off">
                    <div>
                        <TextField required id="standard-required" label="Name" onChange={(event) => { setName(event.target.value) }} />
                    </div>
                    <div>
                        <TextField required id="standard-required" label="Age" onChange={(event) => { setAge(event.target.value) }} />
                    </div>
                    <div>
                        <FormControl>
                            <InputLabel id="demo-simple-select-helper-label">Select Gender</InputLabel>
                            <Select
                                onChange={(event) => { setGender(event.target.value) }}
                                id="demo-simple-select-helper"
                                labelId="demo-simple-select-helper-label"
                            >
                                <MenuItem value="">
                                    <em>None</em>
                                </MenuItem>
                                <MenuItem value='Male'>Male</MenuItem>
                                <MenuItem value='Female'>Female</MenuItem>
                            </Select>
                            <FormHelperText>Some important helper text</FormHelperText>
                        </FormControl>
                    </div>
                    <br />
                    <div>
                        <FormControl>
                            <InputLabel id="demo-simple-select-helper-label">Select Class</InputLabel>
                            <Select
                                onChange={(event) => { setStudentClass(event.target.value) }}
                                id="demo-simple-select-helper"
                                labelId="demo-simple-select-helper-label"
                            >
                                <MenuItem value="">
                                    <em>None</em>
                                </MenuItem>
                                <MenuItem value="6">VI</MenuItem>
                                <MenuItem value="7">VII</MenuItem>
                                <MenuItem value="8">VIII</MenuItem>
                                <MenuItem value="9">IX</MenuItem>
                                <MenuItem value="10">X</MenuItem>
                            </Select>
                            <FormHelperText>Some important helper text</FormHelperText>
                        </FormControl>

                    </div>
                    <br />
                    {/* '', undefined, 0, null, false, NaN */}
                    <div>
                        {studentClass && allSubjects.filter(subject => subject.class === studentClass).map(subject => <FormControlLabel
                            key={subject._id}
                            control={<Checkbox name="checkedA" onChange={(eve) => {
                                
                                let previousState = [...subjects];
                                if (eve.target.checked) {
                                    previousState.push(subject.name)
                                } else {
                                    let index = previousState.indexOf(subject.name)
                                    previousState.splice(index, 1);
                                }
                                console.log("Selected Subjects", previousState)
                                setSubjects(previousState)
                            }} />}
                            label={subject.name}
                        />)}
                    </div>

                </form>
                <br />
                <br />
                <br />
            </CardContent>
            <CardActions>
                <Button variant="contained" color="primary" onClick={sendRequestToSaveStudent}>Save Student</Button>
            </CardActions>
        </Card>
    </>
}