import { useEffect, useState } from 'react'
import SETTINGS from "../../settings"
import { Link } from "react-router-dom"

export default function ListOfAllStudents() {

    let [studentsList, setStudentsList] = useState([])

    useEffect(() => {
        fetch(`${SETTINGS.server_base_url}/students/list-all`)
            .then(res => res.json())
            .then(studentsList => {
                console.log(studentsList.data);
                setStudentsList(studentsList.data)
            })
    }, [])

    return <>
        <table>
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Age</th>
                    <th>Gender</th>
                    <th>Class</th>
                    <th>Subjects</th>
                    <th>Edit</th>
                    <th>Delete</th>
                </tr>
            </thead>
            <tbody>
                {studentsList.map(student => <tr>
                    <td> {student.name}</td>
                    <td> {student.age}</td>
                    <td> {student.gender}</td>
                    <td> {student.class}</td>
                    <td> {student.subjects.join(", ")}</td>
                    <td> <Link to={'/student/' + student._id} >Edit</Link> </td>
                </tr>)}
            </tbody>
        </table>
    </>
} 